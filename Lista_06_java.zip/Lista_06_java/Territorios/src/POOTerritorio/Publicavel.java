package POOTerritorio;

public interface Publicavel {
	
	public String MostraDados();

}